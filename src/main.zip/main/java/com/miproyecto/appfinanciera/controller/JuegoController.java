package com.miproyecto.appfinanciera.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class JuegoController {

    @GetMapping("/juegos")
    public String mostrarJuegos() {
        return "juegos/index";
    }

    @GetMapping("/juegos/verdaderoFalso")
    public String juegoVerdaderoFalso() {
        return "juegos/verdaderoFalso";
    }
    @GetMapping("/juegos/desafio")
    public String mostrarModoDesafio() {
        return "juegos/desafio";
    }
    @GetMapping("/juegos/ahorraGana")
    public String mostrarJuegoAhorraYGana() {
        return "juegos/ahorraGana";
    }

}
